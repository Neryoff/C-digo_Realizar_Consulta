function voltarParaConsulta() {
    window.location.href = "RealizarConsulta.html";
}

function acessarHistorico() {
    window.location.href = "Historico.html";
}